/* ------------------------- common.h -------------------------- */
typedef enum { FALSE, TRUE } bool;

void error( char * );
char *strsave( char * );
void cleararray( char *, int );

